package com.gezijing.rendersky;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Mod(modid = RenderSky.MODID, name = RenderSky.NAME, version = RenderSky.VERSION)
public class RenderSky
{
    public static final String MODID = "rendersky";
    public static final String NAME = "Render Sky";
    public static final String VERSION = "By Tzdgzj";

    private static Logger logger;
    @SidedProxy(clientSide = "com.gezijing.rendersky.ClientProxy", serverSide = "com.gezijing.rendersky.CommonProxy")
    public static CommonProxy proxy;


    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
        logger = event.getModLog();
        Display.setTitle("Render Sky Mod" + "       By Tzdgzj");
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init(event);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        proxy.postInit(event);
    }
    public boolean sky = true;
    public boolean sky1 = false;
    public boolean sky2 = false;
    public boolean sky3 = false;


    @SubscribeEvent
    public void onFogColor (EntityViewRenderEvent.FogColors event) {
            if (sky) {
                Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                    sky = false;
                    sky1 = true;
                }, 1, TimeUnit.MILLISECONDS);
            }
            if (sky1) {
                Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                    sky1 = false;
                    sky2 = true;
                }, 1, TimeUnit.MILLISECONDS);
            }
            if (sky2) {
                Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                    sky2 = false;
                    sky3 = true;
                }, 1, TimeUnit.MILLISECONDS);
            }
            if (sky3) {
                Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()).schedule(() -> {
                    sky3 = false;
                    sky = true;
                }, 1, TimeUnit.MILLISECONDS);
            }

            if (sky) {
                event.setRed(0f);
                event.setGreen(new Random().nextInt());
                event.setBlue(new Random().nextInt());
            }
            if (sky1) {
                event.setRed(new Random().nextInt());
                event.setGreen(0f);
                event.setBlue(new Random().nextInt());
            }
            if (sky2) {
                event.setRed(new Random().nextInt());
                event.setGreen(new Random().nextInt());
                event.setBlue(0f);
            }
            if (sky3) {
                event.setRed(new Random().nextInt());
                event.setGreen(new Random().nextInt());
                event.setBlue(new Random().nextInt());
            }
        }
    }
